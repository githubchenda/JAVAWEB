function addtest() {

    var data=[[${uname}]];

    alert("点击了取消");
    // window.location.href='/testtest?name=abc4';

}
